﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P110_ServiceContainer
{
    public class RandomNumberGenerator
    {
        private static Random _random;

        public RandomNumberGenerator()
        {
            _random = new Random();
            Number = _random.Next(0, 100000);
        }

        public int Number { get; }
    }
}
