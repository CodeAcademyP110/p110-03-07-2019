﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace P110_ServiceContainer.Controllers
{
    public class HotelsController : Controller
    {
        private readonly RandomNumberGenerator _rand;

        public HotelsController(RandomNumberGenerator randomNumberGenerator)
        {
            _rand = randomNumberGenerator;
        }

        public IActionResult Index()
        {
            ViewBag.Number1 = _rand.Number;
            ViewBag.Number2 = _rand.Number;
            return View();
        }
    }
}